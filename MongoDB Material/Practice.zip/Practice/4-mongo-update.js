//updateOne
db.users.updateOne({}, {$set: {age: 42}})
db.users.updateOne({name: "Kanakaraju"}, {$set: {age: 43}})
db.users.updateOne({name: "Kanakaraju"}, {$set: {age: 42, dob: new Date("1975-08-31")}})

//query the above document.
db.users.findOne({dob: new Date("1975-08-31")})

db.users.updateOne({name: "Kanakaraju"}, {$currentDate: {lastModified: true}})

//updateMany
db.users.updateMany({age: {$lt: 20}}, {$currentDate: {lastModified: true}} )

//replaceOne
db.users.insertOne({name: "Vinay", age: 25}
db.users.replaceOne(
	{name: "Vinay"}, 
	{name: "Vijay", age: 26, dob: new Date("1993-04-15"), hobbies: ["Cricket", "Poetry"]} 
)

//update
db.users.update({age: {$lt: 18}}, {$set: {minor: true}})
db.users.update({age: {$lt: 18}}, {$set: {minor: true}}, {multi: true})

//upsert
db.users.updateOne({age: {$gt: 70}}, {$set: {name: "Sameer", age: 70}})
db.users.updateOne({age: {$gt: 70}}, {$set: {name: "Sameer", age: 70}}, {upsert: true})

//update with writeConcern
db.users.updateOne(
	{name: "Sameer"}, 
	{$set: {age: 70, dob: new Date("1949-01-01"), hobbies: ["Travel", "Cooking", "Gardening"]}}, 
	{w: "majority", wtimeout: 500} 
)


// array filters

db.users.updateMany( {marks: {$eq: 110}},  {$set: {"marks.$": 100}} )

db.users.updateOne(
	{marks: {$gt: 100}}, 
	{$set: {"marks.$[score]": 100}},
	{arrayFilters: [{"score": {$gte: 100}}] }
)

db.grades.updateMany(
   { },
   { $set: { "grades.$[elem].mean" : 100 } },
   { arrayFilters: [ { "elem.grade": { $gte: 90 } } ] }
)


//bulkWrite

db.budget.bulkWrite(
  [
	{
		insertOne: { "document": {_id: 11, budget: 26500, expenditure: 26000} } 
	},
	{
		updateOne: { 
					 "filter": {budget: 14000},  
					 "update": {$set: {budget: 14999}} 
				   } 
	},
	{
		deleteOne: { "filter": {_id: 1} } 
	}
  ]
)

// Update Operators
db.users.updateMany( { $or: [{age: 55}, {age: 70}] }, {$inc: {age: 1}} )
db.users.updateMany( { $or: [{age: 56}, {age: 71}] }, {$inc: {age: -1, ageModified: 1}} )

db.emp.updateMany({salary: 84000}, {$mul: {salary: 0.95} })

db.emp.updateMany({}, {$min: {salary: 75000} })  // Salary is cappeda at 75000
db.emp.updateMany({}, {$max: {salary: 40000} })
db.users.updateMany({}, {$unset: {minor: false}})

