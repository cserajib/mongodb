
use train;

db.emp.insertOne({name: "Raju", age: 25, salary: 50000, gender: "male"});
db.emp.insertOne({name: "Amar", age: 26, salary: 55000, gender: "male"});


db.emp.insertMany([ 
{name: "Antony", age: 31, salary: 65000, gender: "male"},
{name: "Komala", age: 23, salary: 38000, gender: "female"},
{name: "Priyanka", age:45, salary: 80000, gender: "female"},
{name: "Sagarika", age:35, salary: 65000, gender: "female"}
]);

db.emp.find().pretty();
db.emp.find( {name: "Amar"} ).pretty();
db.emp.find( {age: {$in:[ 31, 23 ]}} ).pretty();
db.emp.find( {age: {$gt:30}} ).pretty(); 

db.emp.updateOne( {name: "Priyanka"}, {$set: {age: 44}} );
db.emp.updateMany( {}, {$set: {createdOn: new Date()}} );