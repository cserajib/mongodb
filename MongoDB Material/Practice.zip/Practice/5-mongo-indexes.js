
 db.users.createIndex({name: 1})
 db.users.createIndex({name: -1})
 
 db.users.getIndexes()
 db.users.dropIndex({name: 1})
 
  // explain
 // verbosity levels: queryPlanner (default), executionStats, allPlansExecution
 db.users.explain().find({})
 db.users.explain("executionStats").find({})
 db.users.explain("allPlansExecution").find({})
 
 
 //compound Index
 db.users.createIndex({age: 1, name: 1}, {name: "ageAsc_nameAsc"})
 
 // Which plans are selected for the following queries?
 db.users.explain("executionStats").find({age: {$lt: 50}, name: /^A/})
 db.users.explain("executionStats").find({age: {$lt: 20}, name: /^A/})
 db.users.explain("executionStats").find({name: /^A/, age: {$lt: 20}})
 db.users.explain("executionStats").find({$and: [{age: {$gte: 40}}, {age: {$lte: 50}}]});
 db.users.explain("executionStats").find({$or: [{age: {$gte: 30}}, {name: /^K/}]});
 
 // unique index 
 db.users.createIndex({name: 1}, {unique: true})
 
 // partial index
 db.users.createIndex({age: 1}, {partialFilterExpression: {age: {$gt: 40}}})
 
 // index on an embedded document 
 db.users.createIndex({"address.city": 1}) 
 
 //ttl index
 db.log_events.createIndex( { "createdAt": 1 }, { expireAfterSeconds: 60 } )
 db.log_events.insert( {"createdAt": new Date(), "logEvent": 1,"logMessage": "Some Message - 1"} )
 
 //multi-key index
 db.users.createIndex({marks: 1})
 db.users.explain().find({marks: {$gt: 30, $lt: 90}})
 
 //text indexes
 db.products.createIndex({desc: "text"})
  
 db.products.find({$text: {$search: "smart tv"}})
 db.products.find({$text: {$search: "smart -tv"}})
 
 
 
