
db.users.findOne({})

db.users.find({name: "Komala"}).pretty()

db.users.find({_id: ObjectId("5cd4208837bfeb479ae160e9")}).pretty()

db.users.find({age: {$lte: 20}}).pretty()
db.users.find({age: {$lte: 20}, "address.city": "Bangalore"}).pretty()
db.users.find({age: {$in:[ 11, 13 ]}} ).pretty();
db.users.find({name: {$ne: "Komala"}}).pretty()
db.users.find({age: {$nin:[ 11, 13 ]}} ).pretty();

db.users.find( { $or: [ { age: {$gte: 20} }, { "address.city": "Bangalore" } ] } ).pretty()

db.users.find( { $and: [ { age: {$gte: 20} }, { "address.city": "Bangalore" } ] } ).pretty()
db.users.find( { $and: [ { age: {$gte: 40} }, { age: {$lte: 50} } ] } ).pretty();

db.users.findOne( { $or: [ { age: {$gte: 20} }, { "address.city": "Bangalore" } ] } )

db.users.find( { "contact.phone" : { $exists: false } } ).pretty()
db.users.find( { "age" : { $type: "string" } } ).pretty()

db.users.find({"contact.phone": {$exists: true}, $or: [{age: {$gte: 50}}, {name: /^K/}] }).pretty()

db.supplies.find( {
    $expr: {
       $lt:[ {
          $cond: {
             if:   { $gte: ["$qty", 100] },
             then: { $multiply: ["$price", 0.5] },
             else: { $multiply: ["$price", 0.75] }
           }
       }, 5 ] }
} )


//Querying Arrays
db.users.find({hobbies: ["Reading","Movies","Chess"]}).pretty()
db.users.find({hobbies: {$all: ["Movies","Chess", "Reading"]}}).pretty()
db.users.find({hobbies: {$nin: ["Reading"]}}).pretty()
db.users.find({marks: {$gt: 100, $lt: 200 }}).pretty()
db.users.find({marks: {$gt: 90, $lt: 100}}).pretty()
db.users.find({marks: {$elemMatch:{ $gt: 90, $lt: 100 }}}).pretty()

db.users.find({marks: {$elemMatch:{ $gt: 90, $lt: 100 }}}).pretty()


// Projection
db.users.find({age: {$lte: 30}}, {name:1, age:1})
db.users.find({age: {$lte: 30}}, {name:1, age:1, _id: 0})

db.users.find({}, {name:1, age:1, _id: 0, marks: 1})
db.users.find({}, {name:1, age:1, _id: 0, marks: {$slice: 2}})
db.users.find({}, {name:1, age:1, _id: 0, marks: {$slice: -2}})
db.users.find({}, {name:1, age:1, _id: 0, marks: {$slice: [2,2]}})
db.users.find({"contact.email": /ka/}, {name:1, age:1, _id: 0, "contact.email":1})
db.users.find({age: {$gte: 15}}, {marks: {$elemMatch:{$gt: 60, $lt: 90}}}).pretty()
db.users.find({marks: {$gte: 60}}, {name: 1, "marks.$": 1, _id: 0}).pretty()

// ====================
// $lookup   - references

db.emp.aggregate( 
  [ 
	{ 
	   $lookup: { from: "dept", localField: "deptid", foreignField: "_id", as: "empDept" } 
	} 
  ] 
)












